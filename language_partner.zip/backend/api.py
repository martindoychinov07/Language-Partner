from flask import Flask, request, session, jsonify, make_response
from flask_cors import CORS
from datetime import timedelta
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import and_, or_, not_
import hashlib
import datetime
import os


app = Flask(__name__, static_folder='../build', static_url_path='/')
app.secret_key = "Python"
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///app.sqlite3'
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.permanent_session_lifetime = timedelta(days=5)
cors = CORS(
    app,
    resources={r"*": {"origins": "http://localhost:3000"}},
    expose_headers=["Content-Type", "X-CSRFToken"],
    supports_credentials=True,
)
db = SQLAlchemy(app)
app.app_context().push()


class users(db.Model):
    _id = db.Column("id", db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    email = db.Column(db.String(100))
    known_language = db.Column(db.String(100))
    wanted_language = db.Column(db.String(100))
    password = db.Column(db.String(100))
    status = db.Column(db.Integer)

    def __init__(self, name, email, known_language, wanted_language, password, status):
        self.name = name
        self.email = email
        self.known_language = known_language
        self.wanted_language = wanted_language
        self.password = password
        self.status = status


class chat(db.Model):
    _id = db.Column("id", db.Integer, primary_key=True)
    sender = db.Column(db.String(100))
    receiver = db.Column(db.String(100))
    message = db.Column(db.String(100))
    date = db.Column(db.String(100))
    status = db.Column(db.Integer)

    def __init__(self, sender, receiver, message, date, status):
        self.sender = sender
        self.receiver = receiver
        self.message = message
        self.date = date
        self.status = status


class invitations(db.Model):
    _id = db.Column("id", db.Integer, primary_key=True)
    sender = db.Column(db.String(100))
    receiver = db.Column(db.String(100))
    date = db.Column(db.String(100))
    status = db.Column(db.Integer)

    def __init__(self, sender, receiver, date, status):
        self.sender = sender
        self.receiver = receiver
        self.date = date
        self.status = status


class friends(db.Model):
    _id = db.Column("id", db.Integer, primary_key=True)
    accepted = db.Column(db.String(100))
    sent = db.Column(db.String(100))
    date = db.Column(db.String(100))

    def __init__(self, accepted, sent, date):
        self.accepted = accepted
        self.sent = sent
        self.date = date


@app.route('/')
def index():
	return app.send_static_file('index.html')


@app.route("/api/signup", methods=["POST"])
def signup():
    if request.method == "POST":
        if "user" in session:
            return jsonify(type = "error", message = "already.logged.in", code = 403)
        else:
            user_data = request.json
            session.permanent = True
            user = user_data["username"]
            email = user_data["email"]
            password = user_data["password"]
            known_language = user_data["known_language"]
            wanted_language = "" # user_data["wanted_language"]

            session["user"] = user
            session["email"] = email
            session["password"] = password

            salt = "6hgzas"
            hashed = hashlib.md5((password + salt).encode()).hexdigest()
            found_user = users.query.filter_by(name=user).first()

            if found_user:
                return (jsonify(type = "error", message = "user.exists", code = 403))
            else:
                # send_email(email)
                usr = users(user, email, known_language, wanted_language, hashed, 1)
                db.session.add(usr)
                db.session.commit()
            response = make_response(jsonify(name = user, kn_language = known_language, w_language = wanted_language, email = email, password = password), 201)
    return response


@app.route("/api/login", methods=["POST"])
def login():
    if request.method == "POST":
        user_data = request.json
        user = user_data["username"]
        # email = user_data["email"]
        password = user_data["password"]
        found_user = users.query.filter_by(name=user).first()

        if type(found_user) != None:
            if "user" in session and found_user.status == 1:
                return jsonify(type = "warning", message = "user.already.logged.in")
            elif "user" in session and found_user.status == 0:
                return jsonify(type = "error", message = "account.not.verified", code = 403)
            else:
                salt = "6hgzas"

                hashed = hashlib.md5((password + salt).encode()).hexdigest()

                if found_user:
                    if found_user.password == hashed and found_user.status == 1:
                        session["user"] = user
                        # session["email"] = email
                        session["password"] = password
                        return jsonify(type = "warning", message = "successfully.logged.in")
                    elif found_user.password != hashed:
                        return jsonify(type = "error", message = "incorrect.password", code = 403)
                    # elif found_user.email != email:
                    #     return jsonify(type = "error", message = "incorrect.email")
                    elif found_user.status == 0:
                        return jsonify(type = "error", message = "account.not.verified", code = 403)
                else:
                    return jsonify(type = "error", message = "user.not.found", code = 403)
        else:
            return jsonify(type = "error", message = "no.such.user", code = 403)

    return jsonify(type = "warning", message = "logged.in")


@app.route("/api/logout", methods=["POST", "GET"])
def logout():
    if "user" in session:
        session.pop("user", None)
        session.pop("email", None)
        session.pop("kn_language", None)
        session.pop("w_language", None)
        session.pop("password", None)
        return jsonify(type = "warning", message = "user.logged.out")


@app.route("/api/verify", methods=["POST", "GET"])
def verification():
    if request.method == "POST":
        found_user = users.query.filter_by(name=session["user"]).first()
        num = session["code"]
        ver = request.form["ver"]
        if str(ver) == str(num):
            found_user.status = 1
            db.session.add(found_user)
            db.session.commit()
            return jsonify(type = "warning", message = "logged.in")
        elif ver != num or ver == "":
            return jsonify(type = "error", message = "code.incorrect", code = 403)


@app.route("/api/search", methods=["POST"])
def search():
    if request.method == "POST":
        data = request.json
        kn_language = data["kn_language"]
        found_users = []
        if "user" in session:
            found_user = users.query.filter_by(
                known_language=kn_language).all()
            for i in range(len(found_user)):
                if found_user[i].name != session["user"]:
                    found_users.append(found_user[i].name)
            return jsonify(found_users)
        else:
            return jsonify(type = "error", message = "not.logged.in", code = 403)


def get_friends(user):
    found_friends = []
    found_friend = friends.query.filter_by(accepted=user).all()
    for i in range(len(found_friend)):
        found_friends.append(found_friend[i].sent)
    return found_friends


@app.route('/api/profile', methods=["POST"])
def profile():
    if request.method == "POST":
        if "user" in session:
            found_user = users.query.filter_by(name=session["user"]).first()
            if found_user.status == 1:
                user_data = {
                    "name": found_user.name,
                    "email": found_user.email,
                    "kn_language": found_user.known_language,
                    "w_language": found_user.wanted_language
                }
                friends_list = get_friends(session["user"])
                return jsonify(user_data, friends_list)
            else:
                return jsonify(type = "error", message = "account.not.verified", code = 403)
        else:
            return jsonify(type = "error", message = "not.logged.in", code = 403)


@app.route('/api/friends', methods=["GET"])
def friends_list():
    if "user" in session:
        found_user = users.query.filter_by(name = session["user"]).first()
        if found_user:
            user_friends = friends.query.filter_by(accepted = session["user"]).all()
            requested_friends = friends.query.filter_by(sent = session["user"]).all()
            list_friends = []
            for i in range(len(user_friends)):
                list_friends.append(user_friends[i].sent)
            for i in range(len(requested_friends)):
                list_friends.append(requested_friends[i].accepted)
            return jsonify(list_friends)
        else:
            return jsonify(type = "error", message = "no.such.user", code = 403)
    else:
        return jsonify(type = "error", message = "not.logged.in", code = 403)


@app.route('/api/invite', methods=["POST"])
def invite():
    # with open("text.txt", "a") as f:
    #     f.write("1")
    if request.method == "POST":
        found_user = users.query.filter_by(name = session["user"]).first()
        # with open("text.txt", "a") as f:
        #     f.write("2")
        if found_user.status == 1:
            if "user" in session:
                user_data = request.json
                receiver = user_data["receiver"]
                sender = session["user"]
                # with open("text.txt", "a") as f:
                #     f.write("3")
                found_invitation = invitations.query.filter_by(sender = sender, receiver = receiver).first()
                if found_invitation:
                    return jsonify(type = "error", message = "invitation.already.sent", code = 403)
                if receiver == sender:
                    return jsonify(type = "error", message = "user.cant.invite.himself", code = 403)
                found_user = users.query.filter_by(name = receiver).first()
                date = datetime.datetime.now()
                if found_user != None:
                    new_invite = invitations(sender, receiver, date, 0)
                    db.session.add(new_invite)
                    db.session.commit()
                    return jsonify(type = "warning", message = "invitation.sent", code = 403)
                else:
                    return jsonify(type = "error", message = "user.not.found", code = 403)
            else:
                return jsonify(type = "error", message = "not.logged.in", code = 403)
        else:
            return jsonify(type = "error", message = "account.not.verified", code = 403)


@app.route("/api/invited", methods=["GET"])
def invited():
    if request.method == "GET":
        found_user = users.query.filter_by(name=session["user"]).first()
        if found_user.status == 1:
            if "user" in session:
                user = session["user"]
                user_invitations = []
                found_invitation = invitations.query.filter_by(
                    sender=user).all()
                for i in range(len(found_invitation)):
                    user_invitations.append(found_invitation[i].receiver)
                return jsonify(user_invitations)
            else:
                return jsonify(type = "error", message = "not.logged.in", code = 403)
        else:
            return jsonify(type = "error", message = "account.not.verified", code = 403)

@app.route("/api/invitations", methods=["GET"])
def invitation_get():
    if request.method == "GET":
        found_user = users.query.filter_by(name=session["user"]).first()
        if found_user.status == 1:
            if "user" in session:
                user = session["user"]
                user_invitations = []
                found_invitation = invitations.query.filter_by(
                    receiver=user).all()
                for i in range(len(found_invitation)):
                    user_invitations.append(found_invitation[i].sender)
                return jsonify(user_invitations)
            else:
                return jsonify(type = "error", message = "not.logged.in", code = 403)
        else:
            return jsonify(type = "error", message = "account.not.verified", code = 403)


@app.route("/api/accept", methods=["POST"])
def invitation_post():
    if request.method == "POST":
        found_user = users.query.filter_by(name=session["user"]).first()
        if found_user.status == 1:
            if "user" in session:
                data = request.json
                user = session["user"]
                accepted = data["accepted"]
                found_invitation = invitations.query.filter_by(
                    sender=accepted, receiver=user).first()
                date = datetime.datetime.now()
                if found_invitation and found_invitation.status == 0:
                    found_invitation.status = 1
                    new_friend = friends(user, accepted, date)
                    db.session.add(found_invitation)
                    db.session.add(new_friend)
                    db.session.commit()
                    return jsonify(type = "warning", message = "invitation.accepted")
                elif not found_invitation:
                    return jsonify(type = "error", message = "no.such.invitation.found", code = 403)
                else:
                    return jsonify(type = "error", message = "invitation.already.accepted", code = 403)
            else:
                return jsonify(type = "error", message = "not.logged.in", code = 403)
        else:
            return jsonify(type = "error", message = "account.not.verified", code = 403)


@app.route('/api/delete', methods=["POST"])
def delete():
    if request.method == "POST":
        user_data = request.json
        answer = user_data["answer"]
        if "user" in session:
            if answer == 1:
                found_user = users.query.filter_by(
                    name = session["user"]).first()
                db.session.delete(found_user)
                db.session.commit()
                session.pop("user", None)
                session.pop("email", None)
                session.pop("kn_language", None)
                session.pop("kn_language", None)
                session.pop("password", None)
        else:
            return jsonify(type = "error", message = "not.logged.in", code = 403)

    return jsonify(type = "warning", message = "account.deleted")


@app.route("/api/send", methods = ["POST"])
def chat_post():
    if "user" in session:
        sender = session["user"]
    chat_data = request.json

    receiver = chat_data["receiver"]
    message = chat_data["message"]
    if sender == receiver:
        return jsonify(type = "error", message = "user.cant.text.himself", code = 403)
    date = datetime.datetime.now()
    msg = chat(sender, receiver, message, date, 0)
    db.session.add(msg)
    db.session.commit()
    return jsonify(type = "warning", message = "message.delivered")
	
    
@app.route("/api/receive", methods = ["GET"])
def chat_get():
    # wanted_data = request.json
    if "user" in session:
        wanted_receiver = session["user"]
    messages = []

    found_messages = chat.query.filter(
        or_(
            chat.receiver.like(wanted_receiver),
            chat.sender.like(session["user"])
        )
    ).all()

    if len(found_messages) > 0:
        for i in range(len(found_messages)):
            if found_messages[i]:
                found_messages[i].status = 1
                db.session.add(found_messages[i])
                db.session.commit()
                messages.append({"message": found_messages[i].message, "receiver": found_messages[i].receiver, "sender": found_messages[i].sender, "time" : found_messages[i].date})
    return jsonify(messages)


if __name__ == "__main__":
    # db.create_all()
    port = int(os.environ.get('PORT', 5000))
    app.run(debug=True, host='0.0.0.0', port=port)
