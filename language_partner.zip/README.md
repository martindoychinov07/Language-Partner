npx create-react-app frontend --template typescript
cd .\frontend\
npm add antd
npm i --save-dev @types/lodash
npm i js-cookie

npx generate-react-cli component Login
npx generate-react-cli component Contacts
npx generate-react-cli component Messages
