import React, { useState } from 'react';
import 'antd/dist/reset.css';
import './App.css';
import { Col, Layout, Row, Space, Steps, theme } from 'antd';
import { Header, Content, Footer } from 'antd/es/layout/layout';
import { UserOutlined, UserAddOutlined, UsergroupAddOutlined, MessageOutlined } from '@ant-design/icons';
import Login from './components/Login/Login';
import Contacts from './components/Contacts/Contacts';
import Messages from './components/Messages/Messages';
import SignUp from './components/SignUp/SignUp';

function App() {
  const { token } = theme.useToken();
  const [page, setPage] = useState(0);

  const pages = [
    {
      title: 'Login',
      icon: <UserOutlined />,
      content: <Login />,
    },
    {
      title: 'Sign up',
      icon: <UserAddOutlined />,
      content: <SignUp />,
    },
    {
      title: 'Find Friends',
      icon: <UsergroupAddOutlined />,
      content: <Contacts />,
    },
    {
      title: 'Chat With Friends',
      icon: <MessageOutlined />,
      content: <Messages />,
    },
  ];

  const contentStyle: React.CSSProperties = {
    lineHeight: '260px',
    textAlign: 'center',
    color: token.colorTextTertiary,
    backgroundColor: token.colorFillAlter,
    borderRadius: token.borderRadiusLG,
    border: `1px dashed ${token.colorBorder}`,
    marginTop: 16,
  };

  const onChange = (value: number) => {
    console.log('onChange:', value);
    setPage(value);
  };

  return (
    <div className="App">
      <Layout>
        <Header>Header</Header>
        <Content>
          <Steps
            items={pages}
            current={page}
            onChange={onChange}
            labelPlacement="vertical"
          />
          <div style={contentStyle}>
            <Row>
              <Col>{pages[page].content}</Col>
            </Row>
          </div>        
        </Content>
        <Footer>Footer</Footer>
      </Layout>
    </div>
  );
}

export default App;

